# 3Q貢丸 LINE Bot · Render 雲端部署

不用本機 PowerShell,不用 ngrok,不用每天開機。
全程點滑鼠,總共三段共 10 分鐘左右。

---

## 全程預覽

```
段落 1  上傳到 GitHub    3 分鐘   點 3 次滑鼠
段落 2  連到 Render      4 分鐘   點 5 次滑鼠 + 貼 2 個值
段落 3  接回 LINE Console 1 分鐘   貼 1 次 URL
段落 4  代理清理 + 測試  3 分鐘   貼 1 段指令 + 測 7 句
```

---

## 段落 1 · 上傳到 GitHub(3 分鐘)

### 1-1 開 GitHub 帳號

如果還沒有,去 https://github.com/signup 註冊(用 Google SSO 30 秒搞定)

### 1-2 新建一個 repo

去 https://github.com/new

```
Repository name      3qgongwan-bot
Description          3Q貢丸 LINE 客服機器人(可空白)
Public / Private     選 Private(只有你看得到)
Add a README file    不勾(我們自己有)
.gitignore           不勾(我們自己有)
License              None
```

點 **Create repository**

### 1-3 上傳檔案

在新 repo 頁面,點 **uploading an existing file** 連結(在 Quick setup 區塊下方)

```
1. 把 3qgongwan-bot-package 資料夾內 11 個檔案全選
2. 拖曳到 GitHub 上傳區
3. ⚠ 確認 .env 沒被選到(只要 .env.template,不要 .env)
   如果你還沒跑過本機版本,根本不會有 .env,跳過此檢查
4. 下方 Commit message 填:Initial commit
5. 點 Commit changes
```

完成後 repo 頁面會看到所有檔案。

---

## 段落 2 · 連到 Render(4 分鐘)

### 2-1 註冊 Render

去 https://dashboard.render.com/register

選 **Sign up with GitHub**(用同一個 GitHub 帳號最快)

授權 Render 讀取 GitHub repo 權限。

### 2-2 新建 Web Service

進入 Render Dashboard → 右上點 **New +** → 選 **Web Service**

選 **Build and deploy from a Git repository**

在 repo 清單找到剛建的 **3qgongwan-bot** → 點 **Connect**

### 2-3 Render 自動讀 render.yaml

因為我們的 repo 內有 render.yaml,Render 會自動填好以下欄位:

```
Name              3qgongwan-bot
Region            Singapore
Branch            main
Runtime           Python
Build Command     pip install -r requirements.txt
Start Command     uvicorn main:app --host 0.0.0.0 --port $PORT
Plan              Free
```

你只需要點 **Apply**。

### 2-4 填兩個環境變數

進入新建的服務頁 → 左側選 **Environment** → 點 **Add Environment Variable**

```
Key:    LINE_CHANNEL_SECRET
Value:  [從 LINE Developers Console → 3Q貢丸 channel
        → Basic settings → Channel secret 取得]

Key:    LINE_CHANNEL_ACCESS_TOKEN  
Value:  [從 LINE Developers Console → 3Q貢丸 channel
        → Messaging API → Channel access token 點 Issue
        (有效期選 30 days)→ 取得]
```

點 **Save Changes**

⚠ 這兩個值絕對不要貼進對話、不要截圖、不要寫進筆記。Render 後台貼完就關閉。

Render 會自動重新部署服務,等待約 1-3 分鐘。

### 2-5 拿到固定 URL

部署完成後,服務頁面上方會顯示:

```
https://3qgongwan-bot.onrender.com
或類似格式
```

複製這個 URL。

---

## 段落 3 · 接回 LINE Console(1 分鐘)

去 LINE Developers Console → 3Q貢丸 channel → Messaging API 分頁

```
Webhook URL:  [貼剛複製的 Render URL] + /line/webhook

例:https://3qgongwan-bot.onrender.com/line/webhook
```

點 **Update** → 點 **Verify** → 看到綠勾

開啟 **Use webhook** 開關
開啟 **Webhook redelivery** 開關

---

## 段落 4 · 後台清理 + 測試(3 分鐘)

### 4-1 把代理指令貼給瀏覽器代理

把 `agent-instructions-A.txt` 整檔內容貼給瀏覽器代理執行
(把 LINE OA Manager 後台的預設回覆全關掉)

### 4-2 測試 7 條

照 `test-checklist.md` 跑測試。

---

## 大功告成

```
從現在起:
✅ 24/7 自動跑,你電腦關機 bot 還活著
✅ URL 固定不變,LINE Console 設定一次永久
✅ 不用每天開 PowerShell、不用跑 ngrok
✅ 程式碼有更新,push 到 GitHub 自動 redeploy
✅ Render 後台可看執行 log、即時錯誤
```

---

## Render 免費方案小提醒

```
1. 服務閒置 15 分鐘會睡眠,有訊息進來會自動喚醒,首次喚醒
   約等 30 秒;若想避免,用 https://cron-job.org 設每 10 分鐘
   ping 一次 Render URL,保持服務醒著

2. 每月 750 小時免費額度,夠一個服務 24/7 跑

3. Build 失敗看 Render 後台的 Logs 找錯誤訊息

4. 想升級永不睡眠,Starter 方案 USD 7/月
```

---

## 卡點分流

```
卡點 1  GitHub 上傳找不到 .env.template
       → 隱藏檔可能被檔案總管隱藏,
         Mac 按 Cmd+Shift+. 顯示隱藏檔
         Windows 在檔案總管「檢視」勾「隱藏項目」

卡點 2  Render 連 GitHub 後找不到 repo
       → Render 預設只看 Public repo,
         去 GitHub Settings → Applications → Render
         → Configure → 加上 Private repo 存取權限

卡點 3  Build 失敗
       → Render 服務頁面 → Logs 分頁,看錯誤訊息
       → 多半是 requirements.txt 版本問題,改用更鬆綁版本

卡點 4  Verify webhook 不通過
       → Render URL 後面記得加 /line/webhook
       → Render 服務頁面 → Logs 看有沒有 POST 進來

卡點 5  訊息沒回覆但 Render Logs 有看到 POST
       → 環境變數 LINE_CHANNEL_SECRET 或 ACCESS_TOKEN 貼錯了
       → 回 Render Environment 重貼,Save 後會自動 redeploy
```
