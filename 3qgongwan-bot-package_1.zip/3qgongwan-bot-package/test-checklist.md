# 3Q貢丸 LINE Bot 測試清單

修正完成後,做以下測試確認上線狀態。

## 測試前準備

```
1. 刪除既有的 3Q貢丸好友(若已加過)
2. 確認 install.ps1 跑完 + .env 兩值已填
3. 確認 start.ps1 已執行,uvicorn 顯示「running on http://0.0.0.0:8001」
4. 確認另開一個 PowerShell 視窗跑了 ngrok http 8001
5. 確認 LINE Developers Console 的 Webhook URL 已更新為當前 ngrok 網址
6. 確認 LINE OA Manager 後台已照 agent-instructions-A.txt 全部關閉
```

## 7 條測試

| # | 動作 | 預期回覆 |
|---|------|---------|
| 1 | 用 LINE 重新加 3Q貢丸 為好友 | 收到歡迎訊息 + 主選單(若有設 FollowEvent) |
| 2 | 傳「開始生圖」 | 十題探尋表(不應是 30 分鐘諮詢) |
| 3 | 傳「多少錢」 | 兩條服務分流 |
| 4 | 傳「客服」 | 人工小編窗口 |
| 5 | 傳「推廣」 | 客製行銷方案 + 目標承諾書 |
| 6 | 傳「項目有什麼」 | 兩條服務分流 |
| 7 | 連發 5 次「你好」 | 5 次都收主選單(不應出現 LINE 預設「無法個別回覆」訊息) |

## 通過標準

```
6/7 以上正確   =  上線可用
4-5/7         =  仍有路由問題,把錯誤訊息貼回對話,Claude 調整
0-3/7         =  系統層問題,檢查:
                ├─ uvicorn 終端機 log
                ├─ ngrok 終端機 log
                └─ LINE OA Manager 後台設定是否真的全關
```

## 常見卡點對應

```
卡點 1  仍出現「感謝您的訊息!很抱歉...」
       → LINE OA Manager 後台沒清乾淨,再跑一次 agent-instructions-A.txt

卡點 2  完全沒回覆
       → ngrok URL 變了沒同步到 LINE Console
       → 或 uvicorn 已停止(終端機沒看到 INFO log)

卡點 3  回的訊息是程式回但內容錯誤
       → main.py 的 route() 有 bug,把實際輸入和回覆貼回對話

卡點 4  加好友沒收到歡迎訊息
       → 確認 main.py 內 handle_follow 函式存在
       → 確認 LINE OA Manager 後台的 Greeting message 是 OFF
```
