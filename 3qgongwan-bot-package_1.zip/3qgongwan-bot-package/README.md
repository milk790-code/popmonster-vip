# 3Q貢丸 LINE Bot · 部署套件

台灣在地品牌孵化所 · 客服機器人完整部署包

---

## 主推路線 · 雲端部署(完全不用本機操作)

讀 **DEPLOY.md** 一份檔案就能完成,全程點滑鼠。

```
段落 1  上傳到 GitHub    3 分鐘
段落 2  連到 Render      4 分鐘
段落 3  接回 LINE        1 分鐘
段落 4  代理 + 測試      3 分鐘
共  10 分鐘左右
```

優點:
- 24/7 自動跑,你電腦關機 bot 還活著
- URL 固定,設定一次永久
- 不用 PowerShell、不用 venv、不用 ngrok
- Render 免費方案,每月 750 小時夠用

---

## 備用路線 · 本機跑(只在你想學或測試時用)

走本機路線就是「5 步上線」,需要會基本 PowerShell。

```
1. 解壓資料夾到 D:\projects\3qgongwan-bot
2. PowerShell 跑 .\install.ps1
3. 用記事本填 .env 兩個值
4. agent-instructions-A.txt 給代理跑
5. .\start.ps1 + 另開 PowerShell 跑 ngrok http 8001
```

本機路線缺點:電腦關機 bot 就掛,ngrok URL 每次重啟會變。
詳細步驟見 install.ps1 / start.ps1 開頭註解。

---

## 完成後測試

照 `test-checklist.md` 跑 7 條測試,6/7 以上正確就上線可用。

---

## 檔案說明

```
雲端部署用(主推)
├─ DEPLOY.md               雲端部署完整 SOP(讀這份就好)
├─ render.yaml             Render 自動讀的設定檔
├─ requirements.txt        Render 自動裝套件清單

LINE Bot 核心
├─ main.py                 客服機器人主程式(7 路由 + 加好友歡迎)
├─ agent-instructions-A.txt  給瀏覽器代理的 LINE OA 後台清理指令
├─ test-checklist.md       測試 7 條清單

本機跑備用
├─ install.ps1             本機一鍵安裝
├─ start.ps1               本機一鍵啟動
├─ .env.template           本機環境變數範本

工具
├─ .gitignore              防憑證上傳 Git
└─ README.md               本檔
```

---

## 重要安全紅線

```
1. .env 絕對不上傳 Git(.gitignore 已設好)
2. .env 內容絕對不貼進任何對話(包括 Claude)
3. Channel Secret / Access Token 不截圖、不複製到雲端筆記
4. 若不小心外洩 → 立即回 LINE Console 點 Reissue 重發
   → 改 .env → 重啟 uvicorn
```

---

## 日常維運

```
每次開機要跑:
1. 雙擊 start.ps1(或 PowerShell 跑 .\start.ps1)
2. 另開 PowerShell 跑 ngrok http 8001
3. ngrok URL 變了 → 回 LINE Console 重設 Webhook URL

關機:兩個終端機按 Ctrl+C
```

---

## 升級路線(未來)

```
P0 階段(現在)         本機 + ngrok,免費可跑,缺點是電腦關機 bot 就掛
P1 階段(域名搶到後)    上 Render 免費方案,URL 固定,電腦關機不影響
P2 階段(穩定客戶後)    自有 VPS,完全掌握,加資料庫存對話歷史
P3 階段(規模化後)     升 AI 客服(接 Claude API)做語意理解
```
