# 3Q貢丸 LINE Bot 啟動腳本
# 使用方式:在資料夾內雙擊執行,或 PowerShell 跑 .\start.ps1

Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  3Q貢丸 LINE Bot 啟動中..." -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# 檢查 .env 是否填好
if (-not (Test-Path ".env")) {
    Write-Host "錯誤:找不到 .env,請先跑 install.ps1" -ForegroundColor Red
    Read-Host "按 Enter 結束"
    exit 1
}

$envContent = Get-Content ".env" -Raw
if ($envContent -match "LINE_CHANNEL_SECRET=\s*$" -or $envContent -match "LINE_CHANNEL_ACCESS_TOKEN=\s*$") {
    Write-Host "錯誤:.env 還有空白值,請從 LINE Developers Console 取得後填入" -ForegroundColor Red
    Write-Host ""
    Write-Host "需要填的兩個值:"
    Write-Host "  LINE_CHANNEL_SECRET"
    Write-Host "  LINE_CHANNEL_ACCESS_TOKEN"
    Read-Host "按 Enter 結束"
    exit 1
}

# 啟動虛擬環境
& .\.venv\Scripts\Activate.ps1

# 顯示啟動資訊
Write-Host "伺服器啟動於 port 8001" -ForegroundColor Green
Write-Host "另開一個 PowerShell 視窗,執行 ngrok http 8001 取得公開網址" -ForegroundColor Yellow
Write-Host ""
Write-Host "停止伺服器:按 Ctrl+C" -ForegroundColor Gray
Write-Host ""

# 啟動 uvicorn
uvicorn main:app --host 0.0.0.0 --port 8001
